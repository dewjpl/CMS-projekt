import "./Home.scss";
import { Header, Slider, Boxes, Footer } from "./../../components";
import { useContext } from "react";
import { AppContext } from "./../../context/app.context";

const Home = () => {
	const { sectionOrder } = useContext(AppContext);
	return (
		<div className="home-container">
			<Header />
			<div style={{ order: sectionOrder[1] }}>
				<Slider />
			</div>
			<div style={{ order: sectionOrder[2] }}>
				<Boxes />
			</div>
			<div style={{ order: sectionOrder[3] }}>
				<Footer />
			</div>
		</div>
	);
};
export default Home;
