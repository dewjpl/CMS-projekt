import React, { createContext, useState } from "react";

export const AppContext = createContext();

export const AppContextProvider = ({ children }) => {
	const [logged, setLogged] = useState(false);
	const [slider, setSlider] = useState(true);
	const [sliderImg, setSliderImg] = useState({});
	const [boxImg, setBoxImg] = useState({});
	const [backgroundColor, setBackgroundColor] = useState({});
	const [boxColor, setBoxColor] = useState({
		1: "",
		2: "",
		3: "",
	});
	const [footerText, setFooterText] = useState({
		1: "Powered by ",
		2: "dewjpl",
	});
	const [titleText, setTitleText] = useState({});
	const [sectionOrder, setSectionOrder] = useState({
		1: 1,
		2: 2,
		3: 3,
	});

	return (
		<AppContext.Provider
			value={{
				logged,
				setLogged,
				slider,
				setSlider,
				sliderImg,
				setSliderImg,
				boxImg,
				setBoxImg,
				boxColor,
				setBoxColor,
				footerText,
				setFooterText,
				titleText,
				setTitleText,
				backgroundColor,
				setBackgroundColor,
				sectionOrder,
				setSectionOrder,
			}}
		>
			{children}
		</AppContext.Provider>
	);
};
