import "./Dashboard.scss";
import { useContext } from "react";
import { AppContext } from "./../../context/app.context";
import { Link } from "react-router-dom";
import React from "react";

const Dashboard = () => {
	const {
		slider,
		setSlider,
		sliderImg,
		setSliderImg,
		boxImg,
		setBoxImg,
		boxColor,
		setBoxColor,
		footerText,
		setFooterText,
		titleText,
		setTitleText,
		backgroundColor,
		setBackgroundColor,
		sectionOrder,
		setSectionOrder,
	} = useContext(AppContext);

	const setSliderImgHanlder = (e) => {
		const sliderNumber = Number(e.target.name);
		const sliderImgValue = e.target.value;

		sliderImg[sliderNumber] = sliderImgValue;

		setSliderImg(sliderImg);
	};

	const setBoxImgHandler = (e) => {
		const boxNumber = Number(e.target.name);
		const boxImgValue = e.target.value;

		boxImg[boxNumber] = boxImgValue;

		setBoxImg(boxImg);
	};

	const setBoxColorHandler = (e) => {
		const boxNumber = Number(e.target.name);
		const boxColorValue = e.target.value;

		boxColor[boxNumber] = boxColorValue;

		setBoxColor(boxColor);
	};

	const setFooterTextHandler = (e) => {
		const footerNumber = Number(e.target.name);
		const footerNumberValue = e.target.value;

		footerText[footerNumber] = footerNumberValue;

		setFooterText(footerText);
	};
	const setTitleTextHandler = (e) => {
		const titleNumber = Number(e.target.name);
		const titleNumberValue = e.target.value;

		titleText[titleNumber] = titleNumberValue;

		setTitleText(titleText);
	};
	const setBackgroundColorHandler = (e) => {
		const backgroundNumber = Number(e.target.name);
		const backgroundColorValue = e.target.value;

		backgroundColor[backgroundNumber] = backgroundColorValue;

		setBackgroundColor(backgroundColor);
	};
	const setSectionOrderHandler = (e) => {
		const sectionNumber = Number(e.target.name);
		const sectionOrderValue = e.target.value;

		sectionOrder[sectionNumber] = sectionOrderValue;

		setSectionOrder(sectionOrder);
	};
	return (
		<div className="dashboard-container">
			<div className="show-home-btn">
				<Link to="/">Show home page</Link>
			</div>
			<div className="section-settings">
				<div className="title">
					<h2>Slider</h2>
					<button onClick={() => setSlider(!slider)}>
						{slider ? "OFF" : "ON"}
					</button>
				</div>
				<div className="sliders-img">
					<h2>Sliders IMGs</h2>
					<div className="inputs">
						<input
							onChange={(e) => setSliderImgHanlder(e)}
							defaultValue={sliderImg[1]}
							type="text"
							name="1"
						/>
					</div>
					<div className="box-img">
						<h2>Box IMGs</h2>
						<div className="inputs">
							<input
								onChange={(e) => setBoxImgHandler(e)}
								defaultValue={boxImg[1]}
								type="text"
								name="1"
							/>
						</div>
						<div className="inputs">
							<input
								onChange={(e) => setBoxImgHandler(e)}
								defaultValue={boxImg[2]}
								type="text"
								name="2"
							/>
						</div>
						<div className="inputs">
							<input
								onChange={(e) => setBoxImgHandler(e)}
								defaultValue={boxImg[3]}
								type="text"
								name="3"
							/>
						</div>
					</div>
					<div className="background-colors">
						<h2>Background colors</h2>
						<div className="color-input">
							<input
								onChange={(e) => setBackgroundColorHandler(e)}
								defaultValue={backgroundColor[1]}
								type="color"
								name="1"
							/>
							<input
								onChange={(e) => setBackgroundColorHandler(e)}
								defaultValue={backgroundColor[2]}
								type="color"
								name="2"
							/>
						</div>
					</div>
					<div className="box-colors">
						<h2>Box colors</h2>
						<div className="color-input">
							<input
								onChange={(e) => setBoxColorHandler(e)}
								defaultValue={boxColor[1]}
								type="color"
								name="1"
							/>
							<input
								onChange={(e) => setBoxColorHandler(e)}
								defaultValue={boxColor[2]}
								type="color"
								name="2"
							/>
							<input
								onChange={(e) => setBoxColorHandler(e)}
								defaultValue={boxColor[3]}
								type="color"
								name="3"
							/>
						</div>
					</div>

					<div className="footer-text">
						<h2>Footer text</h2>
						<div className="footer-inputs">
							<input
								onChange={(e) => setFooterTextHandler(e)}
								defaultValue={footerText[1]}
								type="text"
								name="1"
							/>
							<input
								onChange={(e) => setFooterTextHandler(e)}
								defaultValue={footerText[2]}
								type="text"
								name="2"
							/>
						</div>
					</div>
					<div className="title-text">
						<h2>Title text</h2>
						<div className="title-inputs">
							<input
								onChange={(e) => setTitleTextHandler(e)}
								defaultValue={titleText[1]}
								type="text"
								name="1"
							/>
						</div>
						<div className="title-inputs">
							<input
								onChange={(e) => setTitleTextHandler(e)}
								defaultValue={titleText[2]}
								type="text"
								name="2"
							/>
						</div>
						<div className="title-inputs">
							<input
								onChange={(e) => setTitleTextHandler(e)}
								defaultValue={titleText[3]}
								type="text"
								name="3"
							/>
						</div>
					</div>
					<div className="section-order">
						<h2>Section order</h2>
						<input
							onChange={(e) => setSectionOrderHandler(e)}
							defaultValue={sectionOrder[1]}
							type="number"
							name="1"
						/>
						<input
							onChange={(e) => setSectionOrderHandler(e)}
							defaultValue={sectionOrder[2]}
							type="number"
							name="2"
						/>
						<input
							onChange={(e) => setSectionOrderHandler(e)}
							defaultValue={sectionOrder[3]}
							type="number"
							name="3"
						/>
					</div>
				</div>
				<div className="settings"></div>
			</div>
		</div>
	);
};

export default Dashboard;
