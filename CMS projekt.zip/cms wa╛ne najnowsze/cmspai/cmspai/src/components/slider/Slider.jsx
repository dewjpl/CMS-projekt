import React from "react";
import "./Slider.scss";
import { useContext } from "react";
import { AppContext } from "../../context/app.context";

const Slider = () => {
	const { sliderImg } = useContext(AppContext);
	const defaultImageSrc =
		"https://turboprezent.pl/media/images/samochody/camaro_ss/camaro_ss.png";
	return (
		<div className="slider-container container">
			<div className="slide slide-1">
				<img src={sliderImg[1] || defaultImageSrc} alt="" />
			</div>
		</div>
	);
};

export default Slider;
