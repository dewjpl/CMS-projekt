import React from "react";
import "./Boxes.scss";
import { useContext } from "react";
import { AppContext } from "../../context/app.context";

const Boxes = () => {
	const { boxImg, boxColor, titleText, backgroundColor } =
		useContext(AppContext);
	const defaultImageSrc1 =
		"https://ocdn.eu/pulscms-transforms/1/Ab-ktkpTURBXy9hOTM3ZGZhMDg3ZmViMWYyMDk5OGI0NGMwMjcxMzJkMy5qcGeSlQMAzQG1zQnEzQV_kwXNBLDNAnY";
	const defaultImageSrc2 =
		"https://i.gremicdn.pl/image/free/2f52f1dc2b6ab852a2fd98ea21818843/?t=crop:1599:992:nowe:0:46,resize:fill:1200:675,enlarge:1";
	const defaultImageSrc3 =
		"https://f.evomagazine.pl/evo_prod_2022_02/thumb-article-183-t1.jpg?v=93e8724a807b6e9e59b5196f55e07ada";

	return (
		<div id="boxes" className="container">
			<div className="boxes" style={{ backgroundColor: backgroundColor[1] }}>
				<div className="box" style={{ backgroundColor: boxColor[1] }}>
					<img src={boxImg[1] || defaultImageSrc1} alt="" />
					<h2>Toyota {titleText[1]}</h2>
					<ul>
						<li>Toyota Corolla</li>
						<li>Toyota Camry</li>
						<li>Toyota RAV4</li>
						<li>Toyota Prius</li>
						<li>Toyota Highlander</li>
					</ul>
				</div>
				<div className="box" style={{ backgroundColor: boxColor[2] }}>
					<img src={boxImg[2] || defaultImageSrc2} alt="" />
					<h2>BMW {titleText[2]}</h2>
					<ul>
						<li>BMW 3 Series</li>
						<li>BMW 5 Series</li>
						<li>BMW X3</li>
						<li>BMW X5</li>
						<li>BMW 7 Series</li>
					</ul>
				</div>
				<div className="box" style={{ backgroundColor: boxColor[3] }}>
					<img src={boxImg[3] || defaultImageSrc3} alt="" />
					<h2>Ford {titleText[3]}</h2>
					<ul>
						<li>Ford Fiesta</li>
						<li>Ford Focus</li>
						<li>Ford Escape</li>
						<li>Ford Explorer</li>
						<li>Ford Emblemer</li>
					</ul>
				</div>
			</div>
		</div>
	);
};

export default Boxes;
